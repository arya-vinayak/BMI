import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';//first get from pub.dev and put on pubspec.yaml

class bmipage extends StatefulWidget {
  bmipage({Key? key, required this.bmi}) : super(key: key);
  double bmi;
  @override
  State<bmipage> createState() => _bmipageState();
}


class _bmipageState extends State<bmipage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.white24,
          title: Text("Result"),
        ),
        body: Center(

          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.white,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                height: 300,
                width: 300,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(30.0),
                      child: Text("Your BMI is:",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 20)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text("${widget.bmi.round()}",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: (widget.bmi > 18) && (widget.bmi < 24) ? Colors.green : Colors.redAccent,
                              fontWeight: FontWeight.bold,
                              fontSize: 35)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(30.0),
                      child: Text("Please rate us:",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14)),
                    ),
                    RatingBar.builder(

                      initialRating: 5,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        switch (index) {
                          case 0:
                            return Icon(
                              Icons.sentiment_very_dissatisfied,
                              color: Colors.red,
                            );
                          case 1:
                            return Icon(
                              Icons.sentiment_dissatisfied,
                              color: Colors.redAccent,
                            );
                          case 2:
                            return Icon(
                              Icons.sentiment_neutral,
                              color: Colors.amber,
                            );
                          case 3:
                            return Icon(
                              Icons.sentiment_satisfied,
                              color: Colors.lightGreen,
                            );
                          case 4:
                            return Icon(
                              Icons.sentiment_very_satisfied,
                              color: Colors.green,
                            );
                          default:
                            return Text("Error");
                        }
                      },
                      onRatingUpdate: (rating) {
                        Text("$rating",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ) );
                      },),
                  ],
                ),
              ),
            ],
          ),
        )
        );


  }
}